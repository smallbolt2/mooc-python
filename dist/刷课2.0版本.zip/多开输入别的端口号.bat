@echo off
cd /d "%~dp0smallbolt2"
start "" smallbolt2.exe
